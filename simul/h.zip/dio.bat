cls
echo off
echo.
echo NightSky Command Terminal
echo Powered by DosBox
echo Copyright(C)2023-2026
echo.
echo on